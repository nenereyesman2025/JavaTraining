package com.ciicc.nespastries.Controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ciicc.nespastries.Repository.produktorepository;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;

@RestController 
@RequiredArgsConstructor 
public class produktocontroller {

    private final produktorepository productRepository;

    @GetMapping ("/produkto")
    public ResponseEntity<?> fetchAll(){

        productRepository.findAll();

        return ResponseEntity.ok(productRepository.findAll());


    }        //after creating Dto folder and file
public ResponseEntity<?>createProduct(RequestBody ProduktoDto produktoDto){
    Product product = new Product(produktoDto.getName(), produktoDto.getPrice());
    productRepository.save(produkto);

    return ResponseEntity.ok(produkto);

}
    
}
