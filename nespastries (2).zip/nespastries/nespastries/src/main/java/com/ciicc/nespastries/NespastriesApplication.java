package com.ciicc.nespastries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NespastriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(NespastriesApplication.class, args);
	}

}
