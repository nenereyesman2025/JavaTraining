package com.ciicc.nespastries.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ciicc.nespastries.entity.Produkto;

public interface produktorepository extends JpaRepository <Produkto, Long> {
    
}
