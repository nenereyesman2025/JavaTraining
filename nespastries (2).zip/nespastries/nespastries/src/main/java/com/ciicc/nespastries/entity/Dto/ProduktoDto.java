package com.ciicc.nespastries.entity.Dto;

import java.math.BigDecimal;

import lombok.Data;

@Data 
public class ProduktoDto {

    private String name;

    private BigDecimal price;
    
}
