package com.ciicc.nespastries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NespastriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
