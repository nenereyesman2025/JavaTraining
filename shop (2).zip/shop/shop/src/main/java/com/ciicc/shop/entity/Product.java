package com.ciicc.shop.entity;

import java.math.BigDecimal;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity 
@Data 
@AllArgsConstructor
@NoArgsConstructor 
@Table (name = "products")

//to create table
public class Product {
    @Id 
    @GeneratedValue (strategy = GenerationType.IDENTITY)

    private long id;

    private String name;

    private BigDecimal price;

    @CreationTimestamp 
    private LocalDateTime createdAt;

    @UpdateTimestamp 
    private LocalDateTime updatedAt;

    public Product(String name, BigDecimal price){
        this.name = name;
        this.price = price;
    }

    
    
    
}
