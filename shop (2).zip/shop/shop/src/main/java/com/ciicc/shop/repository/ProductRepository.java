package com.ciicc.shop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import  com.ciicc.shop.entity.Product;
//DAO                               //hibernate
public interface ProductRepository extends JpaRepository <Product, Long> {


}
    
