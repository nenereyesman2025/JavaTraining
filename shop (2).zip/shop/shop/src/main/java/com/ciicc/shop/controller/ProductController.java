package com.ciicc.shop.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ciicc.shop.entity.Product;
import com.ciicc.shop.entity.dto.ProductDto;
import com.ciicc.shop.repository.ProductRepository;

import lombok.RequiredArgsConstructor;


@RestController 
@RequiredArgsConstructor 

public class ProductController {
    private final ProductRepository productRepository;

    @GetMapping ("/products")
    public ResponseEntity<?> fetchAll(){

        productRepository.findAll();

        return ResponseEntity.ok(productRepository.findAll());


    }
    @PostMapping ("/products")

    public ResponseEntity<?> createProduct(@RequestBody ProductDto productDto) {
        Product product = new Product(productDto.getName(), productDto.getPrice());
        productRepository.save(product);

        return ResponseEntity.ok(product);
    }

}

    
