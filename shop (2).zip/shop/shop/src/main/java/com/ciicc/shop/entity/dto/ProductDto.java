package com.ciicc.shop.entity.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data //getter and setter
public class ProductDto {
    private String name;
    private BigDecimal price;
}
